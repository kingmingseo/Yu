import ".//globals.css";
import MarginWrapper from "@/components/marginwrapper";
import Navigation from "@/components/navigation";
import { authOptions } from "@/pages/api/auth/[...nextauth]";
import { getServerSession } from "next-auth";


export const metadata = {
  title: 'Yu',
  description: "The Best Korean Fashion Model Yu's Page"
};
export default async function RootLayout({ children }) {
  let session = await getServerSession(authOptions);
  console.log(session)

  return (
    <html>
      <body>
        <Navigation session={session}/>
        <MarginWrapper>{children}</MarginWrapper> {/* 경로에 따라 마진 처리 */}
        
      </body>
    </html>
  );
}