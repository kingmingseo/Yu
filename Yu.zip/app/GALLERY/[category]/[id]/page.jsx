export default function Detail(){
  return(
    <>
      <h1>Detail페이지지</h1>
    </>
  )
}