import { connectDB } from "@/util/database";

export default async function Gallery(props) {
  const client = await connectDB;
  const db = client.db("Yu");
  let { category } = await props.params
  category = category.toLowerCase();
  let data = await db.collection(category).find().toArray();
  console.log(data)
  return (
    <>
      <div className="px-4 grid grid-cols-2 gap-x-4 sm:gap-y-32 gap-y-16 pb-32 sm:mt-10 mt-5 justify-between">
        {/* 게시물 1 */}
        <div className="flex flex-col justify-center items-center">
          <img
            src="../profile.jpg"
            alt="Image 1"
            className="sm:w-5/6 object-cover object-top overflow-hidden"
          />
          <h1 className="mt-3 text-sm sm:text-base">2024 Office man</h1>
        </div>

        <div className="flex flex-col justify-center items-center">
          <img
            src="../main2.jpg"
            alt="Image 1"
            className="sm:w-5/6 object-cover object-top overflow-hidden"
          />
          <h1 className="mt-3 text-sm sm:text-base">2024 Office man</h1>
        </div><div className="flex flex-col justify-center items-center">
          <img
            src="../profile.jpg"
            alt="Image 1"
            className="sm:w-5/6 object-cover object-top overflow-hidden"
          />
          <h1 className="mt-3 text-sm sm:text-base">2024 Office man</h1>
        </div>
        <div className="flex flex-col justify-center items-center">
          <img
            src="../profile.jpg"
            alt="Image 1"
            className="sm:w-5/6 object-cover object-top overflow-hidden"
          />
          <h1 className="mt-3 text-sm sm:text-base">2024 Office man</h1>
        </div>
      </div >
    </>
  )
}
