export default function Sponsorship() {
  return (
    <>
      <h1>SPONSORSHIP</h1>
    </>
  )
}
