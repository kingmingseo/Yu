import { connectDB } from "@/util/database";

export default async function Aboutme() {
  const client = await connectDB;
  const db = client.db("Yu");
  let intro = await db.collection("Aboutme").find().toArray();
  
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 w-screen sm:gap-0 gap-5 bg-black">
      <div className="flex sm:justify-end justify-center sm:h-3/4 sm:mr-14">
        <img
          src="profile.jpg"
          alt="Image 1"
          className="sm:w-5/6 object-cover object-top overflow-hidden"
        />
      </div>
      <div className="flex flex-col justify-start sm:ml-14 pl-5 pr-5 sm:mr-14">
        <div className="flex flex-row">
          <h1 className="text-2xl sm:text-4xl font-semibold text-white">
            Yu Gwang Yeong <span className="text-sm sm:text-lg font-extralight ml-2">Fashion Model</span>
          </h1>
        </div>
        <pre className="sm:mt-4 bg-black rounded-md shadow-md font-semibold leading-relaxed text-sm sm:text-base whitespace-pre-wrap sm:mr-14">
          {intro[0].intro}
        </pre>
      </div>
    </div>
  );
}