export default function DailyLife() {
  return (
    <>
      <h1>DAILYLIFE</h1>
    </>
  )
}
