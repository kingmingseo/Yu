import { connectDB } from "@/util/database";
import bcrypt from "bcrypt";

export default async function login(response, requrest) {
  const client = await connectDB;
  const db = client.db("Yu");
  let loginInfo = await db.collection("admin").find().toArray();
  let hash = await bcrypt.hash("dkdlql6617",10)
  console.log(hash)


}